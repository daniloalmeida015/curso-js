console.log(typeof Object)

class Produto {}
console.log(typeof Produto)